# 🧠 VitaCare — Plateforme de Santé Mentale & Coaching

**Projet Web Dynamique 2026 — ING2 ECE Paris**  
Équipe : **Adrien • Raphaël • Axel**

---

## 📋 Présentation

VitaCare est une plateforme web dynamique complète dédiée à la santé mentale et au coaching de vie. Elle permet à des **patients** de réserver des consultations avec des **psychologues et coachs certifiés**, de participer à des **ateliers collectifs**, et de suivre leur parcours de bien-être.

### Positionnement
- **Public cible** : Actifs urbains 25-45 ans, stressés, soucieux de leur santé mentale
- **Contexte** : Accès difficile aux professionnels de santé mentale → centralisation et simplification
- **Différenciation** : Approche holistique (psychologie + coaching + méditation + gestion du stress)

---

## 🏗️ Architecture Technique

```
vitacare/
├── frontend/                 # Application React 18 + Vite
│   ├── src/
│   │   ├── components/       # Layout, Navbar
│   │   ├── context/          # AuthContext, CartContext
│   │   ├── pages/            # 10 pages (Home, Services, Dashboard, etc.)
│   │   └── services/         # api.js (helper fetch)
│   ├── package.json
│   └── vite.config.js
├── backend/                  # PHP 8 — API REST
│   ├── api/                  # auth, services, reservations, activites, panier, notifications, dashboard, categories
│   ├── config/               # database.php, cors.php
│   └── middleware/           # auth.php (sessions)
├── database/
│   └── vitacare.sql          # Schéma complet + données de démo
└── README.md
```

**Stack** : React 18 · PHP 8 · MySQL 8 · Apache (XAMPP)

---

## ⚙️ Installation

### Prérequis
- [XAMPP](https://www.apachefriends.org/) (Apache + PHP 8 + MySQL) **ou** serveur Apache/PHP/MySQL séparé
- [Node.js](https://nodejs.org/) 18+ + npm
- Git

---

### 1. Cloner le dépôt

```bash
git clone https://github.com/VOTRE-REPO/vitacare.git
cd vitacare
```

---

### 2. Base de données MySQL

1. Démarrez **XAMPP** (Apache + MySQL)
2. Ouvrez [phpMyAdmin](http://localhost/phpmyadmin)
3. Créez une base vide (ou laissez le script le faire) :
   ```sql
   CREATE DATABASE vitacare CHARACTER SET utf8mb4;
   ```
4. Importez le schéma :
   ```bash
   mysql -u root -p vitacare < database/vitacare.sql
   ```
   Ou via phpMyAdmin : Importer → sélectionner `database/vitacare.sql`

---

### 3. Backend PHP

1. Copiez le dossier `backend/` dans votre répertoire web Apache :
   - **XAMPP Windows** : `C:/xampp/htdocs/vitacare/backend/`
   - **XAMPP Linux/Mac** : `/opt/lampp/htdocs/vitacare/backend/`

2. Configurez la connexion BDD dans `backend/config/database.php` :
   ```php
   define('DB_HOST', 'localhost');
   define('DB_USER', 'root');     // votre utilisateur MySQL
   define('DB_PASS', '');          // votre mot de passe MySQL
   define('DB_NAME', 'vitacare');
   ```

3. Vérifiez l'URL de base dans `frontend/src/services/api.js` :
   ```js
   const BASE_URL = 'http://localhost/vitacare/backend/api';
   ```

---

### 4. Frontend React

```bash
cd frontend
npm install
npm run dev
```

L'application est accessible sur `http://localhost:5173`

---

### 5. Comptes de démonstration

| Rôle | Email | Mot de passe |
|------|-------|-------------|
| Patient | `julie.dupont@vitacare.fr` | `password` |
| Patient | `pierre.moreau@vitacare.fr` | `password` |
| Praticien | `sophie.martin@vitacare.fr` | `password` |
| Praticien | `thomas.lefevre@vitacare.fr` | `password` |
| Praticien | `claire.bernard@vitacare.fr` | `password` |
| Admin | `admin@vitacare.fr` | `password` |

---

## 🔑 Fonctionnalités Principales

### 👥 Gestion des utilisateurs
- Inscription / connexion sécurisée (sessions PHP + bcrypt)
- 3 rôles : Patient, Praticien, Admin
- Profil utilisateur

### 🔍 Catalogue de services
- Recherche full-text
- Filtres : catégorie, type (individuel/groupe/programme), prix
- Tri : note, prix croissant/décroissant
- 6 catégories : Psychologie, Coaching, Méditation, Gestion du stress, TCC, Bien-être

### 📅 Réservations
- Sélection de créneaux disponibles
- Protection contre les doubles réservations (transactions SQL + SELECT FOR UPDATE)
- Réservation directe ou via panier
- Annulation par le patient
- Historique avec statuts (en attente / confirmé / annulé / terminé)

### 🧘 Activités & programmes
- Inscription aux activités de groupe
- Gestion des capacités (places max)
- Désincription possible

### 🛒 Panier
- Ajout de plusieurs réservations/activités
- Paiement simulé (aucun paiement réel)
- Validation globale avec vérification des disponibilités

### 🔔 Notifications
- Confirmation de réservation
- Rappels
- Marquage lu / suppression

### 📊 Tableau de bord
- **Patient** : prochains RDV, activités inscrites, statistiques
- **Praticien** : prochains rendez-vous, réservations
- **Admin** : KPIs globaux, dernières réservations, activités à venir

---

## 🔐 Sécurité

| Mesure | Implémentation |
|--------|----------------|
| Mots de passe | Hashage bcrypt via `password_hash()` |
| Sessions | PHP sessions avec cookies `httpOnly` |
| CORS | Headers restreints aux origines autorisées |
| Injections SQL | PDO avec requêtes préparées exclusivement |
| Validation | Double validation client (React) + serveur (PHP) |
| Autorisation | Vérification du rôle sur chaque endpoint protégé |
| Concurrence | `SELECT FOR UPDATE` dans des transactions pour éviter les doubles réservations |

---

## ⚠️ Limitations Connues

1. **Paiement simulé** — Aucun paiement réel, simulation pédagogique
2. **Notifications** — Pas de temps réel (pas de WebSockets), chargement à la demande
3. **Images** — Pas de système d'upload d'images (avatars textuels uniquement)
4. **Email** — Pas d'envoi d'email réel (notifications internes uniquement)
5. **Profil** — Modification du profil non implémentée (lecture seule)

---

## 👨‍💻 Équipe & Répartition

| Membre | Rôle principal | Contributions |
|--------|---------------|--------------|
| **Adrien** | Frontend Lead | React architecture, Auth/Cart contexts, Pages Home/ServiceDetail/Panier, fix transactions |
| **Raphaël** | Backend & BDD | Schéma MySQL, API services/réservations/dashboard, tests SQL |
| **Axel** | Backend & Intégration | Config PHP/CORS, API activités/panier/notifs, CSS responsive, README |

---

## 📚 Technologies Utilisées

- **Frontend** : React 18, Vite, React Router v6
- **Backend** : PHP 8, PDO, sessions natives
- **Base de données** : MySQL 8
- **Serveur** : Apache (XAMPP)
- **IA assistante** : Claude / CHAT GPT 

---

*VitaCare — Votre santé mentale, notre priorité* 🧠
