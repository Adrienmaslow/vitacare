# Rapport de compromis techniques – VitaCare

## 1. Architecture générale

Pour VitaCare, nous avons choisi une architecture séparée entre le frontend, le backend et la base de données.

Le frontend est développé avec React/Vite. Il gère l’affichage, la navigation, les formulaires, le panier et les interactions utilisateur.

Le backend est développé en PHP natif. Il reçoit les requêtes du frontend, vérifie les données, applique les règles métier et communique avec la base de données.

La base de données est gérée avec MySQL. Elle stocke les utilisateurs, les services, les créneaux, les réservations, les activités, les inscriptions et les notifications.

Ce choix permet d’avoir une application organisée, avec une séparation claire entre l’interface, les traitements serveur et les données.

## 2. PHP natif plutôt qu’un framework

Nous avons choisi d’utiliser PHP natif pour le backend, sans framework comme Laravel ou Symfony.

Laravel aurait pu apporter une structure plus complète, mais il aurait aussi ajouté une complexité supplémentaire. Dans le cadre de ce projet, PHP natif nous permet de mieux comprendre chaque fichier, chaque requête SQL et chaque vérification réalisée côté serveur.

Ce choix est cohérent avec l’objectif pédagogique du projet, car il permet à l’équipe de maîtriser directement le fonctionnement de l’application.

Limite : sans framework, l’organisation du code dépend davantage de l’équipe. Cette solution est adaptée à un projet étudiant, mais serait moins confortable pour une très grande application professionnelle.

## 3. Communication frontend / backend

Le frontend communique avec le backend grâce à des appels `fetch` vers les fichiers PHP de l’API.

Les données sont échangées sous forme de JSON. Cela permet de séparer proprement l’interface React des traitements effectués côté serveur.

Ce choix rend le projet plus clair : React s’occupe de l’expérience utilisateur, tandis que PHP traite les actions importantes comme la connexion, la réservation ou la validation du panier.

## 4. Gestion des utilisateurs et des rôles

L’application utilise un système d’authentification basé sur les sessions PHP.

Les utilisateurs sont répartis selon plusieurs rôles :
- patient ;
- praticien ;
- administrateur.

Chaque rôle possède des droits différents. Par exemple, un patient peut consulter les services, ajouter des éléments au panier et réserver. Un praticien peut gérer ses services et ses créneaux. Un administrateur peut superviser davantage d’informations sur la plateforme.

Ce système permet d’éviter qu’un utilisateur accède à des fonctionnalités qui ne lui sont pas destinées.

## 5. Base de données MySQL

Nous avons utilisé MySQL car les données de VitaCare sont fortement liées entre elles.

Par exemple, une réservation dépend d’un utilisateur, d’un service et d’un créneau. Une activité peut être liée à plusieurs inscriptions. Les notifications sont rattachées aux utilisateurs.

MySQL permet donc d’organiser ces relations de manière claire à l’aide de tables, de clés primaires et de clés étrangères.

Les requêtes SQL sont réalisées avec PDO et des requêtes préparées, afin de limiter les risques d’injection SQL.

## 6. Réservations et gestion des conflits

La réservation de créneaux est une partie importante du projet.

Avant de valider une réservation, le backend vérifie que le créneau est encore disponible. Cette vérification côté serveur est indispensable, car les informations affichées côté frontend peuvent ne plus être à jour.

Nous avons donc privilégié une validation côté serveur pour garantir une meilleure cohérence des données.

Limite : dans une vraie plateforme avec beaucoup d’utilisateurs connectés en même temps, il faudrait renforcer encore les tests de concurrence et la gestion des erreurs.

## 7. Activités et inscriptions

Les activités collectives fonctionnent avec un système d’inscription.

Avant d’inscrire un utilisateur à une activité, le backend vérifie que l’activité existe et qu’il reste des places disponibles.

Ce choix permet d’éviter les inscriptions incohérentes, comme une inscription à une activité complète ou inexistante.

## 8. Panier et validation

Nous avons mis en place un panier permettant à l’utilisateur de regrouper ses choix avant validation.

Le panier permet d’ajouter des services ou des activités, puis de valider l’ensemble. Lors de la validation, le backend vérifie les informations avant de créer les réservations ou inscriptions correspondantes.

Ce choix améliore l’expérience utilisateur, car il permet de préparer plusieurs actions avant de les confirmer.

## 9. Paiement simulé

Nous n’avons pas intégré de vrai paiement en ligne.

Le paiement est simulé afin de rester dans le cadre pédagogique du projet. Le but est de reproduire le parcours utilisateur : ajout au panier, récapitulatif, validation et confirmation.

Un vrai paiement avec Stripe ou PayPal aurait demandé une configuration plus lourde : clés API, HTTPS, gestion des erreurs de paiement et webhooks.

Limite : le projet ne teste donc pas de vraie transaction bancaire.

## 10. Notifications

Les notifications sont internes à l’application.

Elles permettent d’informer l’utilisateur lorsqu’une action importante est réalisée, par exemple après une réservation ou une inscription.

Nous n’avons pas mis en place d’e-mails réels ni de notifications en temps réel. Cela aurait nécessité une configuration supplémentaire, comme un serveur SMTP ou des WebSockets.

Limite : l’utilisateur doit consulter l’application pour voir ses notifications.

## 11. Sécurité

Plusieurs mesures simples de sécurité ont été mises en place :
- sessions PHP ;
- cookies httpOnly ;
- vérification des rôles ;
- validation des données côté serveur ;
- requêtes préparées avec PDO ;
- hachage des mots de passe.

Ces choix permettent d’avoir un niveau de sécurité cohérent pour un projet pédagogique.

Cependant, pour une vraie mise en production, il faudrait ajouter d’autres protections, comme une configuration HTTPS obligatoire, une meilleure gestion des erreurs et des tests de sécurité plus poussés.

## 12. Fonctionnalités simplifiées ou non développées

Certaines fonctionnalités ont été simplifiées afin de respecter le délai du projet.

Nous n’avons pas intégré :
- de vrai paiement en ligne ;
- d’envoi d’e-mails réels ;
- d’upload d’images ;
- de notifications en temps réel ;
- de statistiques avancées.

Ces choix ont été faits pour se concentrer sur les fonctionnalités principales : inscription, connexion, catalogue, réservation, panier, activités et notifications.

## Conclusion

Les choix techniques de VitaCare ont été faits pour obtenir une application claire, fonctionnelle et compréhensible par l’équipe.

Nous avons privilégié une solution simple avec React, PHP natif et MySQL. Ce choix permet de respecter les contraintes du module tout en gardant une architecture cohérente.

Le principal compromis est d’avoir évité des solutions plus lourdes comme Laravel, Stripe ou les WebSockets, afin de rester concentrés sur les fonctionnalités essentielles et sur la compréhension du code.